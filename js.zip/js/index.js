const headerInput = document.getElementById("headerInput");
const searchBtn = document.getElementById("Search");
const cardContainer = document.getElementById("cards-container");
const totalQuantaty = document.getElementById("totalQuantaty1");
const totalPrise = document.getElementById("totalPrice");
const addTOCard = document.getElementById("addTOCard1");
let TotalPrise = 0;
let TotalQuantaty = 0;
let allProducts;

const url = "https://fakestoreapi.com/products";
let searchCatigory;
async function fetchData() {
  try {
    let response = await fetch(url);
    let products = await response.json();

    if (products === null || products.length === 0) {
      cardContainer.innerHTML = "No products found!";
    } else {
      cardContainer.innerHTML = ""; // Clear previous content

      products.forEach((product) => {
        cardContainer.innerHTML += `
                    <div class="cards">
                        <img src="${product.image}" alt="${product.title}">
                        <p>${product.title}</p>
                        <p class="totalQuantaty1">Price: ${product.price} $</p>
                        <div class="cardBtn">
                            <button id="addTOCard1" class=${product.id}>Add To Cart</button>
                        </div>
                    </div>
                `;
      });
      document.addEventListener("click", (e) => {
        if (e.target.className > 0 || e.target.className <= products.length) {
          TotalQuantaty += 1;
          TotalPrise = TotalPrise + products[e.target.className - 1].price;
          totalQuantaty.innerHTML = `Total Quantity: ${TotalQuantaty}`;
          totalPrise.innerHTML = `Total Prise: ${TotalPrise}`;
        }
      });
    }
    return products;
  } catch (error) {
    console.error("Error fetching data:", error);
    cardContainer.innerHTML = "Failed to load data!";
  }
}

fetchData().then((x) => {
  allProducts = x;
});

// Event listener for the search button
searchBtn.addEventListener("click", async (e) => {
  cardContainer.innerHTML = "";
  searchCatigory = headerInput.value;
  allProducts.filter((product) => {
    if (product.category.includes(searchCatigory))
      cardContainer.innerHTML += `
                        <div class="cards">
                            <img src="${product.image}" alt="${product.title}">
                            <p>${product.title}</p>
                            <p>Price: ${product.price} $</p>
                            <div class="cardBtn">
                                <button class="" id="">View Details</button>
                                <button class="AddToCart" id="AddToCart">Add To Cart</button>
                            </div>
                        </div>
                    `;
  });
});

// document.addEventListener("click",(e)=>{
//     if(e.target.className == "AddToCart"){
//         console.log("ramy")
//         TotalQuantaty += 1;

//         totalQuantaty.innerHTML = `Total Quantity: ${TotalQuantaty}`;
//         totalPrise.innerHTML = `Total Prise: ${TotalPrise}`;
//     }
// })
